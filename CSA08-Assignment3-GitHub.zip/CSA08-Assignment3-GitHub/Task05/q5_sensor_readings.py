"""Q5 – List comprehension: cleaning sensor readings."""
import random
import sys
import time

def valid(c):
    return -50 <= c <= 50

def c_to_f(c):
    return (c * 9 / 5) + 32

def using_loop(readings):
    clean = []
    for c in readings:
        if valid(c):
            clean.append(c)
    fahrenheit = []
    for c in clean:
        fahrenheit.append(c_to_f(c))
    return clean, fahrenheit

def using_comprehension(readings):
    clean = [c for c in readings if valid(c)]
    fahrenheit = [c_to_f(c) for c in clean]
    return clean, fahrenheit

def using_map_filter(readings):
    clean = list(filter(lambda c: valid(c), readings))
    fahrenheit = list(map(lambda c: c_to_f(c), clean))
    return clean, fahrenheit

def main():
    print("Q5 – COLD-STORAGE SENSOR READINGS")
    readings = [1.5, 2.0, 5.5, 9.0, 55.0, -60.0, 7.5, 0.5]
    loop_result = using_loop(readings)
    comp_result = using_comprehension(readings)
    map_result = using_map_filter(readings)
    print("Original Celsius readings:", readings)
    print("Valid Celsius:", loop_result[0])
    print("Fahrenheit:", [round(x, 2) for x in loop_result[1]])
    print("All three methods give same result:", loop_result == comp_result == map_result)
    alarms = [(minute, temp) for minute, temp in enumerate(readings, start=1)
              if valid(temp) and not (2 <= temp <= 8)]
    print("Alarm minutes (outside 2–8 °C, excluding sensor errors):", alarms)
    fahrenheit_by_minute = {minute: round(c_to_f(temp), 2)
                            for minute, temp in enumerate(readings, start=1) if valid(temp)}
    unique_valid = {temp for temp in readings if valid(temp)}
    print("Dictionary comprehension (minute: Fahrenheit):", fahrenheit_by_minute)
    print("Set comprehension (unique valid Celsius):", unique_valid)

    print("\nBenchmark (seconds)")
    for size in (10_000, 100_000, 1_000_000):
        data = [random.uniform(-60, 60) for _ in range(size)]
        timings = []
        for function in (using_loop, using_comprehension, using_map_filter):
            start = time.perf_counter(); function(data); timings.append(time.perf_counter() - start)
        print(f"{size:>9}: loop={timings[0]:.5f}, comprehension={timings[1]:.5f}, map/filter={timings[2]:.5f}")

    generator = (c for c in readings if valid(c))
    materialised = [c for c in readings if valid(c)]
    print("List container size:", sys.getsizeof(materialised), "bytes")
    print("Generator object size:", sys.getsizeof(generator), "bytes")
    print("All-valid test:", using_comprehension([3, 4, 5])[0])
    print("All-invalid test:", using_comprehension([70, -80])[0])

if __name__ == "__main__":
    main()
