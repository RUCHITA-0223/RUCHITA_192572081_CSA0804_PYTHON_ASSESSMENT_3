"""Q1 – Lists and slicing: Daily rainfall records."""
import random
import time

WINDOW = 7

def moving_average_naive(values, window=WINDOW):
    if window <= 0:
        raise ValueError("Window must be positive")
    return [sum(values[i:i + window]) / window
            for i in range(len(values) - window + 1)]

def moving_average_running(values, window=WINDOW):
    if window <= 0:
        raise ValueError("Window must be positive")
    if len(values) < window:
        return []
    current = sum(values[:window])
    result = [current / window]
    for i in range(window, len(values)):
        current += values[i] - values[i - window]
        result.append(current / window)
    return result

def analyse(values):
    print(f"Number of readings: {len(values)}")
    if not values:
        print("No rainfall readings available.")
        return
    weekly_totals = [sum(values[i:i + 7]) for i in range(0, len(values), 7)]
    print("First five weekly totals:", weekly_totals[:5])
    wettest = max(range(len(weekly_totals)), key=weekly_totals.__getitem__)
    driest = min(range(len(weekly_totals)), key=weekly_totals.__getitem__)
    print(f"Wettest week: {wettest + 1}, total = {weekly_totals[wettest]:.2f} mm")
    print(f"Driest week: {driest + 1}, total = {weekly_totals[driest]:.2f} mm")
    averages = moving_average_running(values)
    print("First five 7-day moving averages:", [round(x, 2) for x in averages[:5]])
    dry_days = [i + 1 for i, amount in enumerate(values) if amount == 0]
    print("Dry days (day numbers):", dry_days[:20])
    print("Total dry days:", len(dry_days))

def benchmark():
    print("\nMoving-average benchmark (seconds)")
    for size in (365, 36_500, 365_000):
        data = [random.uniform(0, 80) for _ in range(size)]
        start = time.perf_counter()
        moving_average_naive(data)
        naive_time = time.perf_counter() - start
        start = time.perf_counter()
        moving_average_running(data)
        running_time = time.perf_counter() - start
        print(f"{size:>7} readings | naive: {naive_time:.6f} | running sum: {running_time:.6f}")

def main():
    random.seed(42)
    rainfall = [round(random.uniform(0, 40), 1) for _ in range(365)]
    # Add a few dry days for demonstration.
    for day in (10, 35, 100, 200, 300):
        rainfall[day - 1] = 0.0
    print("Q1 – DAILY RAINFALL ANALYSIS")
    analyse(rainfall)
    print("\nSlicing examples:")
    print("readings[7:14] ->", rainfall[7:14])
    print("readings[-7:]  ->", rainfall[-7:])
    print("readings[::7]  ->", rainfall[::7][:10], "... (first 10 values)")
    print("\nShort-list tests:")
    print("Empty list:", moving_average_running([]))
    print("Fewer than 7 values:", moving_average_running([1, 2, 3]))
    benchmark()

if __name__ == "__main__":
    main()
