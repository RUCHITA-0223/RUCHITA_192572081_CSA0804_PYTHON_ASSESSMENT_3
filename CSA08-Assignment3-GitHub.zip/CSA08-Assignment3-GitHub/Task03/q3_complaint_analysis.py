"""Q3 – Dictionary-based farmer helpline complaint analysis."""
import random
import time
from collections import Counter, defaultdict

CALLS = [
    ("North", "seeds not received seeds delayed", "rice"),
    ("South", "fertiliser price high", "wheat"),
    ("North", "seeds price high subsidy not received", "rice"),
]
STOP = {"not", "high", "the", "is", "a", "and"}

def frequencies(texts, stop):
    counts = {}
    for text in texts:
        for word in text.lower().split():
            word = word.strip(".,!?;:")
            if word and word not in stop:
                counts[word] = counts.get(word, 0) + 1
    return counts

def top(counts, k):
    return sorted(counts.items(), key=lambda item: (-item[1], item[0]))[:k]

def main():
    print("Q3 – FARMER HELPLINE COMPLAINT ANALYSIS")
    texts = [row[1] for row in CALLS]
    counts = frequencies(texts, STOP)
    print("Top 3 words:", top(counts, 3))
    by_district = defaultdict(list)
    by_crop = defaultdict(list)
    for district, complaint, crop in CALLS:
        by_district[district].append(complaint)
        by_crop[crop].append(complaint)
    print("Complaints per district:", {key: len(value) for key, value in by_district.items()})
    print("Complaints grouped by crop:", dict(by_crop))
    print("Dictionary views – keys:", list(counts.keys()))
    print("values:", list(counts.values()))
    print("items:", list(counts.items()))

    print("\nBenchmark (seconds; generated words)")
    vocabulary = ["seed", "water", "crop", "price", "loan", "soil", "pest", "market"]
    for number in (1_000, 10_000, 100_000):
        generated = [" ".join(random.choices(vocabulary, k=12)) for _ in range(number)]
        words = " ".join(generated).split()
        start = time.perf_counter()
        frequencies(generated, set())
        dict_time = time.perf_counter() - start
        start = time.perf_counter()
        unique = set(words)
        list_count_result = {word: words.count(word) for word in unique}
        list_count_time = time.perf_counter() - start
        start = time.perf_counter()
        Counter(words)
        counter_time = time.perf_counter() - start
        print(f"{number:>6} complaints | dict={dict_time:.5f} | list.count={list_count_time:.5f} | Counter={counter_time:.5f}")

    print("\nInput edge tests:")
    print("Empty text:", frequencies([""], STOP))
    print("Mixed case and punctuation:", frequencies(["SEEDS, seeds! High."], STOP))

if __name__ == "__main__":
    main()
