"""Q7 – Contact merging using normalised phone numbers and dictionary/set structures."""
import random
import re
import time

def normalize_phone(phone):
    if not phone:
        return ""
    digits = re.sub(r"\D", "", phone)
    # Treat a leading Indian country code 91 as equivalent to a 10-digit mobile number.
    if len(digits) == 12 and digits.startswith("91"):
        digits = digits[2:]
    return digits

def normalize_name(name):
    return " ".join((name or "").lower().split())

def merge_contacts(contact_lists):
    merged = {}
    for contacts in contact_lists:
        for contact in contacts:
            number = normalize_phone(contact.get("phone", ""))
            email = (contact.get("email") or "").strip().lower()
            name = (contact.get("name") or "").strip()
            # Phone number is the matching key. Contacts without a phone are skipped
            # because there is no reliable unique key in this simple design.
            if not number:
                continue
            if number not in merged:
                merged[number] = {"name": name, "numbers": set(), "emails": set()}
            if name and not merged[number]["name"]:
                merged[number]["name"] = name
            merged[number]["numbers"].add(number)
            if contact.get("phone"):
                merged[number]["numbers"].add(contact["phone"].strip())
            if email:
                merged[number]["emails"].add(email)
    return merged

def main():
    print("Q7 – CONTACT MERGING")
    phone_a = [
        {"name": "Dr. Ravi", "phone": "+91 98400 12345", "email": "RAVI@example.com"},
        {"name": "Anu", "phone": "90000-11111", "email": "anu@example.com"},
    ]
    phone_b = [
        {"name": "ravi kumar", "phone": "9840012345", "email": "ravi.work@example.com"},
        {"name": "Anu", "phone": "9000011111", "email": "ANU@example.com"},
        {"name": "Missing number", "phone": "", "email": "none@example.com"},
    ]
    sim = [
        {"name": "Ravi", "phone": "98400 12345", "email": ""},
        {"name": "Kumar", "phone": "98888 22222", "email": "kumar@example.com"},
    ]
    merged = merge_contacts([phone_a, phone_b, sim])
    for number, details in sorted(merged.items()):
        print(f"Key: {number}")
        print("  Name:", details["name"])
        print("  Numbers:", sorted(details["numbers"]))
        print("  Emails:", sorted(details["emails"]))

    # Performance measurement for 1,000 and 100,000 contacts.
    print("\nBenchmark (seconds)")
    for size in (1_000, 100_000):
        generated = [[{"name": f"Person{i}", "phone": f"900{i % 10000000:07d}",
                       "email": f"person{i}@example.com"} for i in range(size)]]
        start = time.perf_counter()
        merge_contacts(generated)
        dictionary_time = time.perf_counter() - start
        # Pairwise comparison is demonstrated on a capped sample because O(n^2)
        # becomes impractical for 100,000 contacts.
        sample = [item for item in generated[0][:min(size, 2_000)]]
        start = time.perf_counter()
        duplicate_pairs = 0
        for i in range(len(sample)):
            for j in range(i + 1, len(sample)):
                if normalize_phone(sample[i]["phone"]) == normalize_phone(sample[j]["phone"]):
                    duplicate_pairs += 1
        pairwise_time = time.perf_counter() - start
        print(f"{size:>6} contacts | dictionary={dictionary_time:.6f}s | pairwise sample ({len(sample)})={pairwise_time:.6f}s")

if __name__ == "__main__":
    main()
