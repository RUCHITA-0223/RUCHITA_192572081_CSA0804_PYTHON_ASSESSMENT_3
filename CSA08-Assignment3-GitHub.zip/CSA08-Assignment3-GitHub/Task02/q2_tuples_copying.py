"""Q2 – Tuples, mutability and copying."""
import copy
import sys
import time

def main():
    print("Q2 – TUPLES, MUTABILITY AND COPYING")
    rows, cols = 3, 4
    bad = [[0] * cols] * rows
    bad[0][1] = 7
    good = [[0 for _ in range(cols)] for _ in range(rows)]
    good[0][1] = 7
    print("bad :", bad)
    print("good:", good)
    print(bad[0] is bad[1], good[0] is good[1])

    stops = {(13.0827, 80.2707): "Chennai Central",
             (13.0418, 80.2341): "T. Nagar"}
    print(stops[(13.0418, 80.2341)])

    try:
        stops[[13.0418, 80.2341]] = "Invalid list key"
    except TypeError as error:
        print("List as dictionary key:", error)

    original = [[1, 2], [3, 4]]
    alias = original
    shallow = copy.copy(original)
    sliced = original[:]
    deep = copy.deepcopy(original)
    original[0][0] = 99
    original[1].append(5)
    print("Original:", original)
    print("Alias:", alias)
    print("Shallow copy:", shallow)
    print("Slice copy:", sliced)
    print("Deep copy:", deep)

    tuple_with_list = ("bus stop", [10, 20])
    tuple_with_list[1].append(30)
    print("Tuple containing a list after modifying inner list:", tuple_with_list)

    values = list(range(1_000_000))
    tuple_values = tuple(values)
    print("Approx. list container size:", sys.getsizeof(values), "bytes")
    print("Approx. tuple container size:", sys.getsizeof(tuple_values), "bytes")
    # Creation and indexing timings on a smaller repeatable sample.
    sample = list(range(100_000))
    start = time.perf_counter(); list(sample); list_create = time.perf_counter() - start
    start = time.perf_counter(); tuple(sample); tuple_create = time.perf_counter() - start
    start = time.perf_counter(); _ = sample[50_000]; list_index = time.perf_counter() - start
    tup = tuple(sample)
    start = time.perf_counter(); _ = tup[50_000]; tuple_index = time.perf_counter() - start
    print(f"Creation (100,000 values): list={list_create:.6f}s tuple={tuple_create:.6f}s")
    print(f"One indexing operation: list={list_index:.8f}s tuple={tuple_index:.8f}s")

if __name__ == "__main__":
    main()
