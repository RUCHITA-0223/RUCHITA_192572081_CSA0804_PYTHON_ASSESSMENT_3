"""Q6 – Nested data: railway timetable and station index."""
import random
import time

# Each train maps to a dictionary with a name, list of stop tuples, and running-day set.
TIMETABLE = {
    "12601": {"name": "Chennai Express", "stops": [
        ("Chennai", "06:00", "06:15"), ("Katpadi", "08:00", "08:05"),
        ("Bengaluru", "11:00", "11:10")], "days": {"Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"}},
    "12602": {"name": "Southern Mail", "stops": [
        ("Chennai", "07:00", "07:20"), ("Arakkonam", "08:30", "08:35"),
        ("Coimbatore", "14:00", "14:10")], "days": {"Mon", "Wed", "Fri"}},
    "12603": {"name": "Coastal Link", "stops": [
        ("Madurai", "05:00", "05:05"), ("Trichy", "07:00", "07:05"),
        ("Chennai", "12:00", "12:15")], "days": {"Tue", "Thu", "Sat"}},
    "12604": {"name": "Hill Route", "stops": [
        ("Chennai", "09:00", "09:10"), ("Jolarpettai", "11:00", "11:05"),
        ("Bengaluru", "14:00", "14:10")], "days": {"Sun", "Mon", "Tue"}},
    "12605": {"name": "Delta Passenger", "stops": [
        ("Thanjavur", "06:30", "06:35"), ("Trichy", "08:00", "08:05"),
        ("Chennai", "13:30", "13:45")], "days": {"Mon", "Tue", "Wed", "Thu", "Fri"}},
}

def build_station_index(timetable):
    index = {}
    for train_no, info in timetable.items():
        for station, arrival, departure in info["stops"]:
            index.setdefault(station, []).append((train_no, arrival, departure))
    return index

def query_without_index(timetable, station, day):
    found = []
    for train_no, info in timetable.items():
        if day in info["days"]:
            for stop in info["stops"]:
                if stop[0].lower() == station.lower():
                    found.append((train_no, info["name"], stop[1], stop[2]))
    return found

def query_with_index(timetable, index, station, day):
    found = []
    for train_no, arrival, departure in index.get(station, []):
        info = timetable[train_no]
        if day in info["days"]:
            found.append((train_no, info["name"], arrival, departure))
    return found

def main():
    print("Q6 – RAILWAY TIMETABLE")
    for train_no, info in TIMETABLE.items():
        print(f"{train_no} {info['name']} | runs: {', '.join(sorted(info['days']))}")
        for station, arrival, departure in info["stops"]:
            print(f"   {station:12} arrival {arrival} departure {departure}")
    station, day = "Chennai", "Mon"
    index = build_station_index(TIMETABLE)
    print(f"\nTrains stopping at {station} on {day}:")
    result = query_with_index(TIMETABLE, index, station, day)
    result.sort(key=lambda item: item[3])
    for item in result:
        print(item)
    print("Unknown station:", query_with_index(TIMETABLE, index, "Unknown", "Mon"))
    print("Third stop departure for train 12601:", TIMETABLE["12601"]["stops"][2][2])

    print("\nBenchmark with generated timetable (seconds)")
    for count in (100, 1_000, 10_000):
        generated = {}
        stations = [f"Station{i}" for i in range(100)]
        for i in range(count):
            stops = [(random.choice(stations), "08:00", "08:05") for _ in range(8)]
            generated[str(i)] = {"name": f"Train{i}", "stops": stops, "days": {"Mon", "Wed"}}
        start = time.perf_counter()
        query_without_index(generated, "Station5", "Mon")
        scan_time = time.perf_counter() - start
        start = time.perf_counter()
        generated_index = build_station_index(generated)
        index_build_time = time.perf_counter() - start
        start = time.perf_counter()
        query_with_index(generated, generated_index, "Station5", "Mon")
        indexed_time = time.perf_counter() - start
        print(f"{count:>5} trains | scan={scan_time:.6f}s | build index={index_build_time:.6f}s | indexed query={indexed_time:.6f}s")

if __name__ == "__main__":
    main()
