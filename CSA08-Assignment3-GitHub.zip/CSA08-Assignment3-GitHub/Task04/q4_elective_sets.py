"""Q4 – Elective registration clash detection using sets."""
import random
import time

def main():
    print("Q4 – ELECTIVE REGISTRATION CLASH DETECTION")
    ai_elective = {"192311001", "192311004", "192311007", "192311009"}
    iot_elective = {"192311002", "192311004", "192311009", "192311010"}
    all_students = {f"1923110{i:02d}" for i in range(1, 11)}

    # Complete the Code: set operators
    both = ai_elective & iot_elective
    exactly_one = ai_elective ^ iot_elective
    neither = all_students - (ai_elective | iot_elective)

    print("clash      :", sorted(both))
    print("exactly one:", sorted(exactly_one))
    print("neither    :", sorted(neither))

    # Same result using set methods
    both_method = ai_elective.intersection(iot_elective)
    exactly_one_method = ai_elective.symmetric_difference(iot_elective)
    neither_method = all_students.difference(ai_elective.union(iot_elective))
    print("Set-method results match:", (both, exactly_one, neither) ==
          (both_method, exactly_one_method, neither_method))

    print("\nMembership benchmark (seconds)")
    for size in (10_000, 100_000, 1_000_000):
        data = list(range(size))
        data_set = set(data)
        target = size - 1
        start = time.perf_counter(); target in data; list_time = time.perf_counter() - start
        start = time.perf_counter(); target in data_set; set_time = time.perf_counter() - start
        print(f"{size:>9}: list={list_time:.8f}, set={set_time:.8f}")

    print("\nEdge tests:")
    print("Empty electives:", set() & set(), set() ^ set())
    print("Identical electives:", ai_elective & ai_elective, ai_elective ^ ai_elective)

if __name__ == "__main__":
    main()
